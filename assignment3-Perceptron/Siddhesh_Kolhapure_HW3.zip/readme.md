                          
                             Assigment2 ML
                             Siddhesh Vilas Kolhapure
                             B00815336

I have done this assignment completely on my own. I have not copied it, nor have I given my solution to anyone else. I understand that if I am involved in plagiarism or cheating I will have to sign an official form that I have cheated and that this form will be stored in my official university record. I also understand that I will receive a grade of 0 for the involved assignment for my first offense and that I will receive a grade of �F� for the course for any additional offense.

Steps to run the program

1.cd into the folder
2.$ python3 Perceptron.py train test

Output File
--------------------------------------------------------------------
My Navie Bayes Output

Accuracy without stopwords
Accuracy: 94.56066945606695

---------------------------------------------------------------------
My Perceptron Output

Accuracy observed for eta value 0.0087 and interation 22.6829

Filtered Emails classified correctly: 455/478
Accuracy with filtered stopwords: 95.1883%

Therefore perceptrons have good accuracy over naive bayes when eta and the iteration are selected properly.


  
  
  


